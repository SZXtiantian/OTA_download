#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Time    : 2024/9/2 16:00
# @Author  : 钟昊天2021280300
# @FileName: print_test.py
# @Software: PyCharm
import asyncio
import time

while True:
    print("==============")
    time.sleep(2)